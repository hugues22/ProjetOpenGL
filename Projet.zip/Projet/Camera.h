#pragma once
#include <GLFW/glfw3.h>

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

class Camera 
{
private: 
	GLFWwindow & m_Window;
	int m_Width; 
	int m_Height;

	float m_HorizontalAngle; 
	float m_VertivaleAngle;
	float m_InitialFoV;
	float m_Speed;
	float m_MouseSpeed;

	glm::vec3 m_Position;

	glm::mat4 m_Model;
	glm::mat4 m_View;
	glm::mat4 m_Proj; 
	glm::mat4 m_MVP; 

public:
	Camera(GLFWwindow & window, int w, int h);

	void computeMatricesFromInputs();

	inline void computeMVP() { m_MVP = m_Proj * m_View * m_Model; }

	inline glm::mat4 getModel() const { return m_Model; }
	inline glm::mat4 getView() const { return m_View; }
	inline glm::mat4 getProj() const { return m_Proj; }
	inline glm::mat4 getMVP() const { return m_MVP; }
};