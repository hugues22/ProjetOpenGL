//Includes necessaires
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <signal.h>

//Glew
#include <GL/glew.h>

//GLFW
#include <GLFW/glfw3.h>

//GLM
#include <glm/glm.hpp>
#include <glm\gtc\matrix_transform.hpp>

//.h
#include "Cube.h"
#include "Renderer.h"
#include "VertexBuffer.h"
#include "IndexBuffer.h"
#include "VertexArray.h"
#include "Shader.h"
#include "VertexBufferLayout.h"
#include "Texture.h"

using namespace glm;

#define WIDTH 960 
#define HEIGHT 540

int main(void){
	if(!glfwInit())
		return -1;
	
	GLFWwindow* window;
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Create a wubdower mode window and its OpenGL context 
	window = glfwCreateWindow(WIDTH, HEIGHT, "Hello World", NULL, NULL);
	if(!window){
		glfwTerminate();
		return -1;
	}

	// Make the window's context current
	glfwMakeContextCurrent(window);

	glfwSwapInterval(1);

	if (glewInit() != GLEW_OK)
		return -1;
		//std::cout << "Error!" << std::endl;

	std::cout << glGetString(GL_VERSION) << std::endl;
	{
		/*float positions[] = {
			-0.5f, -0.5f, 0.0f, 0.0f, 0.0f, // 0
			 0.5f, -0.5f, 0.0f, 1.0f, 0.0f, // 1
			 0.5f,  0.5f, 0.0f, 1.0f, 1.0f, // 2
			-0.5f,  0.5f, 0.0f, 0.0f, 1.0f  // 3
		};*/


		float positions[] = {
			-1.0f,-1.0f,-1.0f, //0.0f, 0.0f,  // 0
			-1.0f,-1.0f, 1.0f, //1.0f, 0.0f,  // 1 
			-1.0f, 1.0f, 1.0f, //1.0f, 1.0f,  // 2
			 1.0f, 1.0f,-1.0f, //0.0f, 1.0f,  // 3
			-1.0f, 1.0f,-1.0f, //0.0f, 0.0f,  // 4
			 1.0f,-1.0f, 1.0f, //1.0f, 0.0f,  // 5
			 1.0f,-1.0f,-1.0f, //1.0f, 1.0f,  // 6
			 1.0f, 1.0f, 1.0f, //0.0f, 1.0f   // 7
		};					   

		unsigned int indices[] = {
			0, 1, 2,
			3, 0, 4,
			5, 0, 6,
			3, 6, 0,
			0, 2, 4,
			5, 1, 0,
			2, 1, 5,
			7, 6, 3,
			6, 7, 5,
			7, 3, 4,
			7, 4, 2,
			7, 2, 5
		};


		GLCall(glEnable(GL_BLEND));
		GLCall(glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA));


		//cube.setShader("res/shaders/Basic.shader");

		/*VertexArray va;
		VertexBuffer vb(positions, 3 * 8 * sizeof(float));

		VertexBufferLayout layout; 
		layout.Push<float>(3);
		//layout.Push<float>(2);
		va.AddBuffer(vb, layout);

		IndexBuffer ib(indices, 3 * 12);

		Shader shader("res/shaders/Basic.shader");
		Texture texture("res/Textures/texture2.png");*/

		//Textures 
		//shader.Bind();
		//texture.Bind(/* rien = 0, doit avoir la m�me valeur que dans la ligne d'en dessous !! );*/
		//shader.setUniform1i("u_Texture", 0);

		/*va.Unbind();
		vb.Unbind();
		ib.Unbind();
		texture.Unbind();
		shader.Unbind();*/

		Cube cube(positions, indices, "res/shaders/Basic.shader");
		
		Renderer renderer(*window, WIDTH, HEIGHT);
		
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		//int loop = 0;
		
		while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS && glfwWindowShouldClose(window) == 0)
		{
			//printf("loop : %d", ++loop);
			/* Render here */
			GLCall(glClear(GL_COLOR_BUFFER_BIT));

			//renderer.Draw(cube);
			renderer.Draw(cube.getVertexArray(), cube.getIndexBuffer(), cube.getShader());
			//renderer.Draw(va, ib, shader);

			/* Swap frint and back buffers */
			glfwSwapBuffers(window);

			/* Poll for and process envents */
			glfwPollEvents();
		}
	}

	glfwTerminate();
	return 0;
}

