#include "Renderer.h"

#include "VertexArray.h"
#include "IndexBuffer.h"
#include "Shader.h"
#include "Cube.h"


void GLClearError() {
	while (glGetError() != GL_NO_ERROR);
}

bool GLLogCall(const char* function, const char* file, int line) {
	while (GLenum error = glGetError()) {
		printf("OpenGL Error ( %d ) : %s, %s, %d", error, function, file, line);
		return false;
	}
	return true;
}

Renderer::Renderer(GLFWwindow & window, int w, int h)
	: m_Camera(new Camera(window, w, h))
{
}

void Renderer::Draw(const VertexArray& va, const IndexBuffer& ib, Shader& shader)
{
	m_Camera->computeMatricesFromInputs();
	m_Camera->computeMVP();
	
	glm::mat4 mvp = m_Camera->getMVP();

	shader.Bind();
	shader.setUniformMat4f("u_MVP", mvp);

	va.Bind();
	ib.Bind();

	GLCall(glDrawElements(GL_TRIANGLES, ib.getCount(), GL_UNSIGNED_INT, nullptr));

}

void Renderer::Draw(Cube cube)
{
	m_Camera->computeMatricesFromInputs();
	m_Camera->computeMVP();

	glm::mat4 mvp = m_Camera->getMVP();
	
	
	cube.Bind();
	/*cube.getShader().Bind();
	cube.getShader().setUniformMat4f("u_MVP", mvp);*/
	cube.setShaderUniformMat4f("u_MVP", mvp);

	cube.getVertexArray().Bind();
	cube.getIndexBuffer().Bind();

	GLCall(glDrawElements(GL_TRIANGLES, cube.getIndexBuffer().getCount(), GL_UNSIGNED_INT, nullptr));
	
}